﻿using GameEngine.Graphics;
using GameEngine.Graphics.Bufers;
using OpenTK.Mathematics;
using System.Reflection.Metadata.Ecma335;

namespace GameEngine.Core.Resources.Loaders
{
    public class MeshLoaders
    {
        public static List<Mesh> LoadObjMesh(string path)
        {
            string fileName = Path.GetFileNameWithoutExtension(path);
            string filePath = Path.GetFullPath(path);
            int index = filePath.IndexOf(fileName);
            filePath = filePath.Remove(index);

            List<Mesh> meshs = new List<Mesh>();
            List<Material> materials = new List<Material>();
            List<Vector3> positions = new List<Vector3>();
            List<Vector3> normals = new List<Vector3>();
            List<Vector2> texCoords = new List<Vector2>();
            List<uint> indices = new List<uint>();
            Material material = Material.Default;
            string meshName = string.Empty;

            List<Vertex> vertices = new List<Vertex>();

            using (StreamReader sr = new StreamReader(path))
            {
                while (!sr.EndOfStream)
                {
                    string line = sr.ReadLine()!;

                    string[] word = line.Split(' ');

                    switch (word[0])
                    {
                        case "o":
                            if (vertices.Count > 0)
                            {
                                meshs.Add(CreateMesh(vertices, indices, material, meshName));
                                positions = new List<Vector3>();
                                normals = new List<Vector3>();
                                texCoords = new List<Vector2>();
                                indices = new List<uint>();
                                vertices = new List<Vertex>();
                            }
                            meshName = word[1];
                            break;

                        case "v":
                            positions.Add(new Vector3(float.Parse(word[1]),
                                float.Parse(word[2]), float.Parse(word[3])));
                            break;
                        case "vn":
                            normals.Add(new Vector3(float.Parse(word[1]),
                                float.Parse(word[2]), float.Parse(word[3])));
                            break;
                        case "vt":
                            texCoords.Add(new Vector2(float.Parse(word[1]), float.Parse(word[2])));
                            break;

                        case "f":
                            //for (int i = 1; i < word.Length; i++)
                            {
                                string[] f1 = word[2].Split('/');
                                string[] f2 = word[3].Split('/');
                                string[] f3 = word[1].Split('/');

                                indices.Add(uint.Parse(f1[0]));
                                indices.Add(uint.Parse(f2[0]));
                                indices.Add(uint.Parse(f3[0]));

                                //for (int i = 0; i < 3; i++)
                                {
                                    vertices.AddRange(CreateVertices(word, positions, normals, texCoords));
                                }
                            }
                            break;

                        case "mtllib":
                            materials = MaterialMtlLoader(filePath + word[1]);
                            break;

                        case "usemtl":
                            material = materials.Find(m => m.Name == word[1]);
                            break;
                    }
                }
            }

            meshs.Add(CreateMesh(vertices, indices, material, meshName));

            return meshs;
        }

        private static Vertex[] CreateVertices(string[] words, List<Vector3> positions, List<Vector3> normals, List<Vector2> texCoords)
        {
            Vertex[] vertices = new Vertex[3];

            for (int i = 0; i < 3; i++)
            {
                int[] indices = words[i + 1].Split('/').Select(f => int.Parse(f) - 1).ToArray();

                if (indices.Length == 3)
                    vertices[i] = new Vertex(positions[indices[0]], texCoords[indices[1]], normals[indices[2]]);
                else if (indices.Length == 2)
                    vertices[i] = new Vertex(positions[indices[0]], texCoords[indices[1]]);
                else if (indices.Length == 1)
                    vertices[i] = new Vertex(positions[indices[0]]);
            }
            return vertices;
        }

        private static Mesh CreateMesh(List<Vertex> vertices, List<uint> indices, Material material, string meshName)
        {
            VertexBuffer buffer = new VertexBuffer(vertices.ToArray());
            IndexBuffer indexBuffer = new IndexBuffer(indices.ToArray());
            VertexArray vertexArray = new VertexArray(buffer, indexBuffer);

            return new Mesh(vertexArray, material, meshName);
        }

        public static List<Material> MaterialMtlLoader(string path)
        {
            if (!File.Exists(path))
                throw new Exception("File is not found.");

            List<Material> materials = new List<Material>();

            Material material = new Material();

            using(StreamReader  sr = new StreamReader(path))
            {
                while(!sr.EndOfStream)
                {
                    string line = sr.ReadLine()!;

                    string[] word = line.Split(' ');

                    switch (word[0])
                    {
                        case "newmtl":
                            material = new Material(word[1]);
                            materials.Add(material);
                            break;

                        case "Ns":
                            material.Shininess = float.Parse(word[1]);
                            break;

                        case "Ka":
                            material.Ambient = new Vector3(float.Parse(word[1]),
                                float.Parse(word[2]), float.Parse(word[3]));
                            break;
                        case "Ks":
                            material.Specular = new Vector3(float.Parse(word[1]),
                                float.Parse(word[2]), float.Parse(word[3]));
                            break;
                        case "Kd":
                            material.Diffuse = new Vector3(float.Parse(word[1]),
                                float.Parse(word[2]), float.Parse(word[3]));
                            break;

                        case "map_Kd":
                            string txPath = word.Length > 2 ? word[1] + " " + word[2] : word[1];
                            material.TexDiff = Texture.LoadFromFile("Assets\\" + txPath);
                            break;

                        case "map_Ks":
                            txPath = word.Length > 2 ? word[1] + " " + word[2] : word[1];
                            material.TexSpec = Texture.LoadFromFile("Assets\\" + txPath);
                            break;

                        case "map_Bump":
                            txPath = word.Length > 2 ? word[1] + " " + word[2] : word[1];
                            material.TexNorm = Texture.LoadFromFile("Assets\\" + txPath);
                            break;
                    }

                    if (materials.Count > 0)
                        materials[materials.Count - 1] = material;
                }
            }

            return materials;
        }
    }
}
